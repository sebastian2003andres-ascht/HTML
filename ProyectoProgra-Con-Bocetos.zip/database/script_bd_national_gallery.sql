-- =====================================================
-- Base de datos: Sistema Web The National Gallery
-- Motor: PostgreSQL
-- Autores: Dylan Aguilar y Andrés Chiluisa
-- =====================================================

-- Borramos las tablas si ya existen (para poder ejecutar el script varias veces)
DROP TABLE IF EXISTS detalle_compra CASCADE;
DROP TABLE IF EXISTS compras CASCADE;
DROP TABLE IF EXISTS bitacora CASCADE;
DROP TABLE IF EXISTS productos CASCADE;
DROP TABLE IF EXISTS obras CASCADE;
DROP TABLE IF EXISTS historia CASCADE;
DROP TABLE IF EXISTS usuarios CASCADE;

-- =====================================================
-- DDL: creación de tablas
-- =====================================================

-- Usuarios del sistema (cliente, empleado y administrador)
CREATE TABLE usuarios (
    id_usuario     SERIAL PRIMARY KEY,
    nombre         VARCHAR(100) NOT NULL,
    correo         VARCHAR(100) NOT NULL UNIQUE,
    contrasena     VARCHAR(255) NOT NULL,
    rol            VARCHAR(20)  NOT NULL
                   CHECK (rol IN ('cliente', 'empleado', 'administrador')),
    bloqueado      BOOLEAN      NOT NULL DEFAULT FALSE,
    fecha_registro TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- Obras de la colección del museo
CREATE TABLE obras (
    id_obra     SERIAL PRIMARY KEY,
    titulo      VARCHAR(150) NOT NULL,
    artista     VARCHAR(100) NOT NULL,
    anio        INTEGER,
    descripcion TEXT,
    imagen      VARCHAR(255),
    sala        VARCHAR(50)
);

-- Contenido de la página de Historia (línea de tiempo del museo)
CREATE TABLE historia (
    id_historia SERIAL PRIMARY KEY,
    anio        INTEGER,
    titulo      VARCHAR(150) NOT NULL,
    contenido   TEXT         NOT NULL,
    imagen      VARCHAR(255)
);

-- Productos de la tienda (entradas, libros, postales y recuerdos)
CREATE TABLE productos (
    id_producto SERIAL PRIMARY KEY,
    nombre      VARCHAR(100) NOT NULL,
    tipo        VARCHAR(20)  NOT NULL
                CHECK (tipo IN ('entrada', 'libro', 'postal', 'recuerdo')),
    descripcion TEXT,
    precio      NUMERIC(8,2) NOT NULL CHECK (precio >= 0),
    stock       INTEGER      NOT NULL DEFAULT 0 CHECK (stock >= 0),
    imagen      VARCHAR(255)
);

-- Compras realizadas por los clientes
CREATE TABLE compras (
    id_compra    SERIAL PRIMARY KEY,
    id_usuario   INTEGER       NOT NULL REFERENCES usuarios(id_usuario),
    fecha        TIMESTAMP     NOT NULL DEFAULT NOW(),
    fecha_visita DATE,
    total        NUMERIC(10,2) NOT NULL DEFAULT 0,
    estado       VARCHAR(20)   NOT NULL DEFAULT 'pendiente'
                 CHECK (estado IN ('pendiente', 'aprobada', 'rechazada'))
);

-- Productos que contiene cada compra
CREATE TABLE detalle_compra (
    id_detalle      SERIAL PRIMARY KEY,
    id_compra       INTEGER      NOT NULL REFERENCES compras(id_compra) ON DELETE CASCADE,
    id_producto     INTEGER      NOT NULL REFERENCES productos(id_producto),
    cantidad        INTEGER      NOT NULL CHECK (cantidad > 0),
    precio_unitario NUMERIC(8,2) NOT NULL
);

-- Bitácora del sistema (auditoría)
CREATE TABLE bitacora (
    id_bitacora SERIAL PRIMARY KEY,
    fecha_hora  TIMESTAMP    NOT NULL DEFAULT NOW(),
    accion      VARCHAR(200) NOT NULL,
    ip          VARCHAR(45)  NOT NULL,
    id_usuario  INTEGER REFERENCES usuarios(id_usuario)
);

-- =====================================================
-- DML: datos de ejemplo
-- (Las contraseñas están en texto plano solo para las pruebas.
--  Cuando hagamos el login en Spring se cifran.)
-- =====================================================

INSERT INTO usuarios (nombre, correo, contrasena, rol) VALUES
('Administrador', 'admin@nationalgallery.com',   'admin1234',   'administrador'),
('Empleado Demo', 'empleado@nationalgallery.com', 'empleado1234', 'empleado'),
('Cliente Demo',  'cliente@nationalgallery.com',  'cliente1234',  'cliente');

INSERT INTO obras (titulo, artista, anio, descripcion, imagen, sala) VALUES
('Los girasoles', 'Vincent van Gogh', 1888, 'Naturaleza muerta con girasoles en un jarrón.', 'girasoles.jpg', 'Sala 1'),
('El Temerario remolcado a su último atraque', 'J. M. W. Turner', 1839, 'Un viejo barco de guerra es remolcado al atardecer.', 'temerario.jpg', 'Sala 2'),
('El carro de heno', 'John Constable', 1821, 'Paisaje del campo inglés con un carro cruzando el río.', 'carro_heno.jpg', 'Sala 3'),
('Los embajadores', 'Hans Holbein el Joven', 1533, 'Retrato doble con un cráneo distorsionado en primer plano.', 'embajadores.jpg', 'Sala 4'),
('La Venus del espejo', 'Diego Velázquez', 1650, 'Venus recostada mirando su reflejo en un espejo.', 'venus_espejo.jpg', 'Sala 5'),
('Bañistas en Asnières', 'Georges Seurat', 1884, 'Jóvenes descansando a orillas del río Sena.', 'banistas.jpg', 'Sala 6');

INSERT INTO historia (anio, titulo, contenido, imagen) VALUES
(1824, 'Fundación del museo', 'El museo nació cuando el Parlamento británico compró la colección de John Julius Angerstein.', 'fundacion.jpg'),
(1838, 'El edificio de Trafalgar Square', 'El museo abrió en el edificio diseñado por William Wilkins en Trafalgar Square, Londres.', 'edificio.jpg');

INSERT INTO productos (nombre, tipo, descripcion, precio, stock, imagen) VALUES
('Entrada general',          'entrada',  'Acceso al museo por un día.',            10.00, 500, 'entrada_general.jpg'),
('Entrada estudiante',       'entrada',  'Acceso con descuento para estudiantes.',  5.00, 300, 'entrada_estudiante.jpg'),
('Guía de la colección',     'libro',    'Libro con las obras más importantes.',   18.50,  40, 'guia.jpg'),
('Postal Los girasoles',     'postal',   'Postal con la obra de Van Gogh.',         1.50, 200, 'postal_girasoles.jpg'),
('Taza The National Gallery','recuerdo', 'Taza de cerámica con el logo del museo.', 9.99,  60, 'taza.jpg'),
('Bolsa de tela',            'recuerdo', 'Bolsa de tela con diseño del museo.',     7.50,  80, 'bolsa.jpg');

-- Una compra de ejemplo del cliente (2 entradas + 1 postal)
INSERT INTO compras (id_usuario, fecha_visita, total, estado) VALUES
(3, '2026-12-05', 21.50, 'aprobada');

INSERT INTO detalle_compra (id_compra, id_producto, cantidad, precio_unitario) VALUES
(1, 1, 2, 10.00),
(1, 4, 1, 1.50);

INSERT INTO bitacora (accion, ip, id_usuario) VALUES
('Inicio de sesión del administrador',    '172.17.42.10', 1),
('Registro de nuevo usuario: Cliente Demo', '172.17.42.50', 3),
('Compra realizada #1',                   '172.17.42.50', 3);

-- Consulta de prueba: histórico de compras con el nombre del cliente
-- SELECT c.id_compra, u.nombre, c.fecha, c.total
-- FROM compras c JOIN usuarios u ON u.id_usuario = c.id_usuario;
