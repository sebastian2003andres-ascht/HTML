# Bocetos de The National Gallery

Este directorio contiene el archivo editable de Draw.io y las vistas previas de las 11 pantallas. Las imágenes se pueden consultar directamente desde GitHub.

[Abrir el archivo editable de Draw.io](Bocetos_National_Gallery_Redisenado.drawio)

## Vistas previas

### 1. Inicio

![Inicio](previews/boceto-01.png)

### 2. Historia

![Historia](previews/boceto-02.png)

### 3. Obras

![Obras](previews/boceto-03.png)

### 4. Tienda

![Tienda](previews/boceto-04.png)

### 5. Iniciar sesión y Registro

![Iniciar sesión y Registro](previews/boceto-05.png)

### 6. Cliente - Mi cuenta

![Cliente - Mi cuenta](previews/boceto-06.png)

### 7. Empleado - Gestionar obras

![Empleado - Gestionar obras](previews/boceto-07.png)

### 8. Empleado - Compras de clientes

![Empleado - Compras de clientes](previews/boceto-08.png)

### 9. Admin - Usuarios

![Admin - Usuarios](previews/boceto-09.png)

### 10. Admin - Bitácora

![Admin - Bitácora](previews/boceto-10.png)

### 11. Admin - Aprobar registros

![Admin - Aprobar registros](previews/boceto-11.png)
