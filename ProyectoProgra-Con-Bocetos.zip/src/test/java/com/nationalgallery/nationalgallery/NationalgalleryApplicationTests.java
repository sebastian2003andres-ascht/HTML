package com.nationalgallery.nationalgallery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NationalgalleryApplicationTests {

	@Test
	void contextLoads() {
	}

}
