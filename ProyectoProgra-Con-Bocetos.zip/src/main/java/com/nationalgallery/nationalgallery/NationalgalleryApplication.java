package com.nationalgallery.nationalgallery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NationalgalleryApplication {

	public static void main(String[] args) {
		SpringApplication.run(NationalgalleryApplication.class, args);
	}

}
