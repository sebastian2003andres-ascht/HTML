package com.nationalgallery.nationalgallery;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nationalgallery.nationalgallery.repository.UsuarioRepository;

@Controller
public class InicioController {

	private final UsuarioRepository usuarioRepository;

	public InicioController(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}

	// Página principal
	@GetMapping("/")
	public String inicio() {
		return "index"; // busca el archivo templates/index.html
	}

	// Página de prueba: muestra cuántos usuarios hay en la base de datos
	@GetMapping("/prueba-bd")
	@ResponseBody
	public String pruebaBd() {
		return "Usuarios en la base de datos: " + usuarioRepository.count();
	}

}
