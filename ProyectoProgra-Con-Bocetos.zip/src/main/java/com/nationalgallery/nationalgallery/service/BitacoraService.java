package com.nationalgallery.nationalgallery.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.nationalgallery.nationalgallery.model.Bitacora;
import com.nationalgallery.nationalgallery.repository.BitacoraRepository;

import jakarta.servlet.http.HttpServletRequest;

// Guarda una fila en la bitácora: fecha y hora, acción, IP del cliente y usuario
@Service
public class BitacoraService {

	private final BitacoraRepository bitacoraRepository;

	public BitacoraService(BitacoraRepository bitacoraRepository) {
		this.bitacoraRepository = bitacoraRepository;
	}

	public void registrar(String accion, HttpServletRequest request, Long idUsuario) {
		Bitacora b = new Bitacora();
		b.setFechaHora(LocalDateTime.now());
		b.setAccion(accion);
		b.setIp(request.getRemoteAddr()); // IP de quien hizo la petición
		b.setIdUsuario(idUsuario);
		bitacoraRepository.save(b);
	}

}
