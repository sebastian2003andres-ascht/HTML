package com.nationalgallery.nationalgallery.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nationalgallery.nationalgallery.model.Compra;
import com.nationalgallery.nationalgallery.model.DetalleCompra;
import com.nationalgallery.nationalgallery.model.Producto;
import com.nationalgallery.nationalgallery.repository.CompraRepository;
import com.nationalgallery.nationalgallery.repository.DetalleCompraRepository;
import com.nationalgallery.nationalgallery.repository.ProductoRepository;

@Service
public class CompraService {

	private final CompraRepository compraRepository;
	private final DetalleCompraRepository detalleCompraRepository;
	private final ProductoRepository productoRepository;

	public CompraService(CompraRepository compraRepository, DetalleCompraRepository detalleCompraRepository,
			ProductoRepository productoRepository) {
		this.compraRepository = compraRepository;
		this.detalleCompraRepository = detalleCompraRepository;
		this.productoRepository = productoRepository;
	}

	// @Transactional = "todo o nada": si algo falla, no se guarda nada a medias
	@Transactional
	public Compra comprar(Long idUsuario, Map<Long, Integer> carrito, LocalDate fechaVisita) {

		// 1. Revisamos que haya stock y calculamos el total
		BigDecimal total = BigDecimal.ZERO;
		for (Map.Entry<Long, Integer> item : carrito.entrySet()) {
			Producto p = productoRepository.findById(item.getKey()).orElse(null);
			if (p == null) {
				throw new IllegalArgumentException("Un producto de tu carrito ya no existe.");
			}
			if (p.getStock() < item.getValue()) {
				throw new IllegalArgumentException("No hay suficiente stock de: " + p.getNombre());
			}
			total = total.add(p.getPrecio().multiply(BigDecimal.valueOf(item.getValue())));
		}

		// 2. Guardamos la compra (queda pendiente hasta que el administrador la apruebe)
		Compra compra = new Compra();
		compra.setIdUsuario(idUsuario);
		compra.setFecha(LocalDateTime.now());
		compra.setFechaVisita(fechaVisita);
		compra.setTotal(total);
		compra.setEstado("pendiente");
		compra = compraRepository.save(compra);

		// 3. Guardamos cada producto de la compra y descontamos el stock
		for (Map.Entry<Long, Integer> item : carrito.entrySet()) {
			Producto p = productoRepository.findById(item.getKey()).orElse(null);

			DetalleCompra detalle = new DetalleCompra();
			detalle.setIdCompra(compra.getIdCompra());
			detalle.setIdProducto(p.getIdProducto());
			detalle.setCantidad(item.getValue());
			detalle.setPrecioUnitario(p.getPrecio()); // el precio de hoy
			detalleCompraRepository.save(detalle);

			p.setStock(p.getStock() - item.getValue());
			productoRepository.save(p);
		}

		return compra;
	}

	// El administrador aprueba una compra pendiente
	@Transactional
	public void aprobar(Long idCompra) {
		Compra compra = compraRepository.findById(idCompra).orElse(null);
		if (compra == null) {
			throw new IllegalArgumentException("La compra no existe.");
		}
		if (!"pendiente".equals(compra.getEstado())) {
			throw new IllegalArgumentException("Esa compra ya fue revisada.");
		}
		compra.setEstado("aprobada");
		compraRepository.save(compra);
	}

	// El administrador rechaza una compra pendiente: el stock vuelve a la tienda
	@Transactional
	public void rechazar(Long idCompra) {
		Compra compra = compraRepository.findById(idCompra).orElse(null);
		if (compra == null) {
			throw new IllegalArgumentException("La compra no existe.");
		}
		if (!"pendiente".equals(compra.getEstado())) {
			throw new IllegalArgumentException("Esa compra ya fue revisada.");
		}
		compra.setEstado("rechazada");
		compraRepository.save(compra);

		// Devolvemos al stock lo que se había descontado
		for (DetalleCompra d : detalleCompraRepository.findByIdCompra(idCompra)) {
			Producto p = productoRepository.findById(d.getIdProducto()).orElse(null);
			if (p != null) {
				p.setStock(p.getStock() + d.getCantidad());
				productoRepository.save(p);
			}
		}
	}

}
