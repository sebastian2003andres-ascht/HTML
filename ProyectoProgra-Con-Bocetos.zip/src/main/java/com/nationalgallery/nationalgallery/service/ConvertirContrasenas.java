package com.nationalgallery.nationalgallery.service;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.nationalgallery.nationalgallery.model.Usuario;
import com.nationalgallery.nationalgallery.repository.UsuarioRepository;

// Se ejecuta una vez cada vez que arranca el proyecto.
// Cifra las contraseñas que estén en texto plano (las 3 del script SQL).
@Component
public class ConvertirContrasenas implements CommandLineRunner {

	private final UsuarioRepository usuarioRepository;

	public ConvertirContrasenas(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;
	}

	@Override
	public void run(String... args) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		for (Usuario u : usuarioRepository.findAll()) {
			// Una contraseña cifrada con BCrypt siempre empieza con "$2"
			if (!u.getContrasena().startsWith("$2")) {
				u.setContrasena(encoder.encode(u.getContrasena()));
				usuarioRepository.save(u);
			}
		}
	}

}
