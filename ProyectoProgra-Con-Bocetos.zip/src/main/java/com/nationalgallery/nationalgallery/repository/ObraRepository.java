package com.nationalgallery.nationalgallery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nationalgallery.nationalgallery.model.Obra;

public interface ObraRepository extends JpaRepository<Obra, Long> {

	List<Obra> findAllByOrderByIdObraAsc();

	// Busca por título o por artista (sin importar mayúsculas)
	List<Obra> findByTituloContainingIgnoreCaseOrArtistaContainingIgnoreCase(String titulo, String artista);

}
