package com.nationalgallery.nationalgallery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nationalgallery.nationalgallery.model.Bitacora;

public interface BitacoraRepository extends JpaRepository<Bitacora, Long> {

	// Todos los registros, del más nuevo al más antiguo
	List<Bitacora> findAllByOrderByFechaHoraDesc();

}
