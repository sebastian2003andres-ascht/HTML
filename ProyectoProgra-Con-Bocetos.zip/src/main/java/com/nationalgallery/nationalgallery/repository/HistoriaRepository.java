package com.nationalgallery.nationalgallery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nationalgallery.nationalgallery.model.Historia;

public interface HistoriaRepository extends JpaRepository<Historia, Long> {

	// De la más antigua a la más nueva
	List<Historia> findAllByOrderByAnioAsc();

}
