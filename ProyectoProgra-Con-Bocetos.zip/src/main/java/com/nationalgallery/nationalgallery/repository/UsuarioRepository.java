package com.nationalgallery.nationalgallery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nationalgallery.nationalgallery.model.Usuario;

// Con esto Spring ya sabe guardar, buscar y borrar usuarios (no hay que escribir SQL)
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

	// Busca un usuario por su correo (devuelve null si no existe)
	Usuario findByCorreo(String correo);

	// Todos los usuarios ordenados por id
	List<Usuario> findAllByOrderByIdUsuarioAsc();

}
