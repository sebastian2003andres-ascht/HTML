package com.nationalgallery.nationalgallery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nationalgallery.nationalgallery.model.DetalleCompra;

public interface DetalleCompraRepository extends JpaRepository<DetalleCompra, Long> {

	// Los productos de una compra
	List<DetalleCompra> findByIdCompra(Long idCompra);

}
