package com.nationalgallery.nationalgallery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nationalgallery.nationalgallery.model.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

	List<Producto> findAllByOrderByIdProductoAsc();

	// Productos de un tipo (entrada, libro, postal o recuerdo)
	List<Producto> findByTipoOrderByIdProductoAsc(String tipo);

}
