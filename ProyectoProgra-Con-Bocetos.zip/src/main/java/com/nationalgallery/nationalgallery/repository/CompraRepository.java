package com.nationalgallery.nationalgallery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nationalgallery.nationalgallery.model.Compra;

public interface CompraRepository extends JpaRepository<Compra, Long> {

	// Las compras de un cliente, de la más nueva a la más antigua
	List<Compra> findByIdUsuarioOrderByFechaDesc(Long idUsuario);

	// Todas las compras de todos los clientes, de la más nueva a la más antigua
	List<Compra> findAllByOrderByFechaDesc();

}
