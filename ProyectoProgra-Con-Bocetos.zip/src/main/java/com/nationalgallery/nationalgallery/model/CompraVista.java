package com.nationalgallery.nationalgallery.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

// Una compra lista para mostrarla en una tabla (no es una tabla de la base de datos)
public class CompraVista {

	private Long idCompra;
	private String fecha;
	private String fechaVisita;
	private String cliente; // nombre del cliente (lo usa el Empleado)
	private BigDecimal total;
	private String estado;
	private List<String> lineas = new ArrayList<>(); // ej: "2 x Entrada general"

	public Long getIdCompra() {
		return idCompra;
	}

	public void setIdCompra(Long idCompra) {
		this.idCompra = idCompra;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getFechaVisita() {
		return fechaVisita;
	}

	public void setFechaVisita(String fechaVisita) {
		this.fechaVisita = fechaVisita;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public List<String> getLineas() {
		return lineas;
	}

}
