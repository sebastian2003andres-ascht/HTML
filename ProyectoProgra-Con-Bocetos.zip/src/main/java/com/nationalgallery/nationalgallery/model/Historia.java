package com.nationalgallery.nationalgallery.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

// Representa la tabla "historia"
@Entity
@Table(name = "historia")
public class Historia {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idHistoria;

	private Integer anio;
	private String titulo;
	private String contenido;
	private String imagen;

	public Long getIdHistoria() {
		return idHistoria;
	}

	public void setIdHistoria(Long idHistoria) {
		this.idHistoria = idHistoria;
	}

	public Integer getAnio() {
		return anio;
	}

	public void setAnio(Integer anio) {
		this.anio = anio;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getContenido() {
		return contenido;
	}

	public void setContenido(String contenido) {
		this.contenido = contenido;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

}
