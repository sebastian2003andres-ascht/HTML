package com.nationalgallery.nationalgallery.model;

import java.math.BigDecimal;

// Una fila del carrito: producto, cantidad y subtotal (no es una tabla)
public class LineaCarrito {

	private Producto producto;
	private Integer cantidad;
	private BigDecimal subtotal;

	public LineaCarrito(Producto producto, Integer cantidad, BigDecimal subtotal) {
		this.producto = producto;
		this.cantidad = cantidad;
		this.subtotal = subtotal;
	}

	public Producto getProducto() {
		return producto;
	}

	public Integer getCantidad() {
		return cantidad;
	}

	public BigDecimal getSubtotal() {
		return subtotal;
	}

}
