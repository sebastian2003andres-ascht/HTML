package com.nationalgallery.nationalgallery.controller;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nationalgallery.nationalgallery.model.Usuario;
import com.nationalgallery.nationalgallery.repository.UsuarioRepository;
import com.nationalgallery.nationalgallery.service.BitacoraService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class LoginController {

	private final UsuarioRepository usuarioRepository;
	private final BitacoraService bitacoraService;
	private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	public LoginController(UsuarioRepository usuarioRepository, BitacoraService bitacoraService) {
		this.usuarioRepository = usuarioRepository;
		this.bitacoraService = bitacoraService;
	}

	// Muestra el formulario de inicio de sesión
	@GetMapping("/login")
	public String mostrarLogin() {
		return "login";
	}

	// Recibe el correo y la contraseña
	@PostMapping("/login")
	public String iniciarSesion(@RequestParam("correo") String correo,
			@RequestParam("contrasena") String contrasena,
			HttpServletRequest request, HttpSession session, Model model) {

		Usuario u = usuarioRepository.findByCorreo(correo);

		// 1. ¿Existe el usuario y la contraseña es correcta?
		if (u == null || !encoder.matches(contrasena, u.getContrasena())) {
			bitacoraService.registrar("Intento de inicio de sesión fallido: " + correo, request, null);
			model.addAttribute("error", "Correo o contraseña incorrectos.");
			return "login";
		}

		// 2. ¿Está bloqueado? (bloqueado = true no puede entrar)
		if (Boolean.TRUE.equals(u.getBloqueado())) {
			bitacoraService.registrar("Intento de inicio de sesión de usuario bloqueado: " + correo, request, u.getIdUsuario());
			model.addAttribute("error", "Tu usuario está bloqueado. Comunícate con el administrador.");
			return "login";
		}

		// 3. Todo bien: guardamos los datos en la sesión
		session.setAttribute("idUsuario", u.getIdUsuario());
		session.setAttribute("nombre", u.getNombre());
		session.setAttribute("rol", u.getRol());
		bitacoraService.registrar("Inicio de sesión: " + correo, request, u.getIdUsuario());

		// 4. Cada rol va a su propia pantalla
		if (u.getRol().equals("administrador")) {
			return "redirect:/admin";
		}
		if (u.getRol().equals("empleado")) {
			return "redirect:/empleado";
		}
		return "redirect:/cliente";
	}

	// Cerrar sesión
	@GetMapping("/logout")
	public String cerrarSesion(HttpServletRequest request, HttpSession session) {
		Long idUsuario = (Long) session.getAttribute("idUsuario");
		if (idUsuario != null) {
			bitacoraService.registrar("Cierre de sesión", request, idUsuario);
		}
		session.invalidate(); // borra la sesión
		return "redirect:/login";
	}

}
