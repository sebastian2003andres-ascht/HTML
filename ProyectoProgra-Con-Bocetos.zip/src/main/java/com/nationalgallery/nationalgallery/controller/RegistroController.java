package com.nationalgallery.nationalgallery.controller;

import java.time.LocalDateTime;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nationalgallery.nationalgallery.model.Usuario;
import com.nationalgallery.nationalgallery.repository.UsuarioRepository;
import com.nationalgallery.nationalgallery.service.BitacoraService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class RegistroController {

	private final UsuarioRepository usuarioRepository;
	private final BitacoraService bitacoraService;
	private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	public RegistroController(UsuarioRepository usuarioRepository, BitacoraService bitacoraService) {
		this.usuarioRepository = usuarioRepository;
		this.bitacoraService = bitacoraService;
	}

	// Muestra el formulario vacío
	@GetMapping("/registro")
	public String mostrarFormulario() {
		return "registro";
	}

	// Recibe los datos del formulario
	@PostMapping("/registro")
	public String registrar(@RequestParam("nombre") String nombre,
			@RequestParam("correo") String correo,
			@RequestParam("contrasena") String contrasena,
			@RequestParam("confirmar") String confirmar,
			HttpServletRequest request, Model model) {

		// Devolvemos lo escrito para que no tenga que volver a escribirlo si hay error
		model.addAttribute("nombre", nombre);
		model.addAttribute("correo", correo);

		// Validaciones en el servidor
		if (nombre.isBlank()) {
			model.addAttribute("error", "El nombre es obligatorio.");
			return "registro";
		}
		if (!correo.matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")) {
			model.addAttribute("error", "El correo no tiene un formato válido.");
			return "registro";
		}
		// Expresión regular: mínimo 8 caracteres
		if (!contrasena.matches("^.{8,}$")) {
			model.addAttribute("error", "La contraseña debe tener mínimo 8 caracteres.");
			return "registro";
		}
		if (!contrasena.equals(confirmar)) {
			model.addAttribute("error", "Las contraseñas no coinciden.");
			return "registro";
		}
		if (usuarioRepository.findByCorreo(correo) != null) {
			model.addAttribute("error", "Ese correo ya está registrado.");
			return "registro";
		}

		// Todo está bien: creamos el usuario como "cliente"
		Usuario u = new Usuario();
		u.setNombre(nombre);
		u.setCorreo(correo);
		u.setContrasena(encoder.encode(contrasena)); // se guarda cifrada
		u.setRol("cliente");
		u.setBloqueado(false);
		u.setFechaRegistro(LocalDateTime.now());
		usuarioRepository.save(u);

		// Anotamos el registro en la bitácora
		bitacoraService.registrar("Nuevo usuario registrado: " + correo, request, u.getIdUsuario());

		model.addAttribute("exito", "Cuenta creada correctamente.");
		model.addAttribute("nombre", "");
		model.addAttribute("correo", "");
		return "registro";
	}

}
