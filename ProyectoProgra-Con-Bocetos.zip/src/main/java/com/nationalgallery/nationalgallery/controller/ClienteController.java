package com.nationalgallery.nationalgallery.controller;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nationalgallery.nationalgallery.model.Compra;
import com.nationalgallery.nationalgallery.model.CompraVista;
import com.nationalgallery.nationalgallery.model.DetalleCompra;
import com.nationalgallery.nationalgallery.model.Producto;
import com.nationalgallery.nationalgallery.model.Usuario;
import com.nationalgallery.nationalgallery.repository.CompraRepository;
import com.nationalgallery.nationalgallery.repository.DetalleCompraRepository;
import com.nationalgallery.nationalgallery.repository.ProductoRepository;
import com.nationalgallery.nationalgallery.repository.UsuarioRepository;
import com.nationalgallery.nationalgallery.service.BitacoraService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

// Pantalla "Mi cuenta" del cliente: histórico de compras y cambio de contraseña
@Controller
public class ClienteController {

	private final UsuarioRepository usuarioRepository;
	private final CompraRepository compraRepository;
	private final DetalleCompraRepository detalleCompraRepository;
	private final ProductoRepository productoRepository;
	private final BitacoraService bitacoraService;
	private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	public ClienteController(UsuarioRepository usuarioRepository, CompraRepository compraRepository,
			DetalleCompraRepository detalleCompraRepository, ProductoRepository productoRepository,
			BitacoraService bitacoraService) {
		this.usuarioRepository = usuarioRepository;
		this.compraRepository = compraRepository;
		this.detalleCompraRepository = detalleCompraRepository;
		this.productoRepository = productoRepository;
		this.bitacoraService = bitacoraService;
	}

	private boolean esCliente(HttpSession session) {
		return "cliente".equals(session.getAttribute("rol"));
	}

	// Mi cuenta: cambio de contraseña + histórico de compras
	@GetMapping("/cliente")
	public String miCuenta(HttpSession session, Model model) {
		if (!esCliente(session)) {
			return "redirect:/login";
		}
		Long idUsuario = (Long) session.getAttribute("idUsuario");
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

		// Convertimos cada compra en una "vista" fácil de mostrar
		List<CompraVista> compras = new ArrayList<>();
		for (Compra c : compraRepository.findByIdUsuarioOrderByFechaDesc(idUsuario)) {
			CompraVista v = new CompraVista();
			v.setIdCompra(c.getIdCompra());
			v.setFecha(c.getFecha().format(formato));
			v.setFechaVisita(c.getFechaVisita() == null ? "-" : c.getFechaVisita().toString());
			v.setTotal(c.getTotal());
			v.setEstado(c.getEstado());

			for (DetalleCompra d : detalleCompraRepository.findByIdCompra(c.getIdCompra())) {
				Producto p = productoRepository.findById(d.getIdProducto()).orElse(null);
				String nombreProducto = (p == null) ? "Producto" : p.getNombre();
				v.getLineas().add(d.getCantidad() + " x " + nombreProducto);
			}
			compras.add(v);
		}

		model.addAttribute("nombre", session.getAttribute("nombre"));
		model.addAttribute("compras", compras);
		return "cliente";
	}

	// Cambiar la contraseña
	@PostMapping("/cliente/password")
	public String cambiarPassword(@RequestParam("actual") String actual,
			@RequestParam("nueva") String nueva,
			@RequestParam("confirmar") String confirmar,
			HttpServletRequest request, HttpSession session, RedirectAttributes ra) {

		if (!esCliente(session)) {
			return "redirect:/login";
		}
		Long idUsuario = (Long) session.getAttribute("idUsuario");
		Usuario u = usuarioRepository.findById(idUsuario).orElse(null);
		if (u == null) {
			return "redirect:/login";
		}

		if (!encoder.matches(actual, u.getContrasena())) {
			ra.addFlashAttribute("error", "La contraseña actual no es correcta.");
			return "redirect:/cliente";
		}
		if (!nueva.matches("^.{8,}$")) {
			ra.addFlashAttribute("error", "La contraseña nueva debe tener mínimo 8 caracteres.");
			return "redirect:/cliente";
		}
		if (!nueva.equals(confirmar)) {
			ra.addFlashAttribute("error", "Las contraseñas nuevas no coinciden.");
			return "redirect:/cliente";
		}

		u.setContrasena(encoder.encode(nueva));
		usuarioRepository.save(u);
		bitacoraService.registrar("Cambio de contraseña: " + u.getCorreo(), request, idUsuario);

		ra.addFlashAttribute("exito", "Contraseña actualizada correctamente.");
		return "redirect:/cliente";
	}

}
