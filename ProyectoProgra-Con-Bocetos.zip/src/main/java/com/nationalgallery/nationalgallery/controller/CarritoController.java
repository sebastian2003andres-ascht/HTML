package com.nationalgallery.nationalgallery.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nationalgallery.nationalgallery.model.Compra;
import com.nationalgallery.nationalgallery.model.LineaCarrito;
import com.nationalgallery.nationalgallery.model.Producto;
import com.nationalgallery.nationalgallery.repository.ProductoRepository;
import com.nationalgallery.nationalgallery.service.BitacoraService;
import com.nationalgallery.nationalgallery.service.CompraService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class CarritoController {

	private final ProductoRepository productoRepository;
	private final CompraService compraService;
	private final BitacoraService bitacoraService;

	public CarritoController(ProductoRepository productoRepository, CompraService compraService,
			BitacoraService bitacoraService) {
		this.productoRepository = productoRepository;
		this.compraService = compraService;
		this.bitacoraService = bitacoraService;
	}

	// Solo los clientes pueden usar el carrito
	private boolean esCliente(HttpSession session) {
		return "cliente".equals(session.getAttribute("rol"));
	}

	// El carrito se guarda en la sesión: un mapa de "id del producto" -> "cantidad"
	@SuppressWarnings("unchecked")
	private Map<Long, Integer> obtenerCarrito(HttpSession session) {
		Map<Long, Integer> carrito = (Map<Long, Integer>) session.getAttribute("carrito");
		if (carrito == null) {
			carrito = new LinkedHashMap<>();
			session.setAttribute("carrito", carrito);
		}
		return carrito;
	}

	// Agregar un producto al carrito
	@PostMapping("/carrito/agregar")
	public String agregar(@RequestParam("idProducto") Long idProducto,
			@RequestParam("cantidad") Integer cantidad,
			HttpSession session, RedirectAttributes ra) {

		if (session.getAttribute("rol") == null) {
			return "redirect:/login";
		}
		if (!esCliente(session)) {
			return "redirect:/tienda";
		}
		Producto p = productoRepository.findById(idProducto).orElse(null);
		if (p == null) {
			return "redirect:/tienda";
		}
		if (cantidad == null || cantidad < 1) {
			cantidad = 1;
		}

		Map<Long, Integer> carrito = obtenerCarrito(session);
		int nuevaCantidad = carrito.getOrDefault(idProducto, 0) + cantidad;
		if (nuevaCantidad > p.getStock()) {
			ra.addFlashAttribute("error", "No hay suficiente stock de ese producto.");
			return "redirect:/tienda/" + idProducto;
		}
		carrito.put(idProducto, nuevaCantidad);
		return "redirect:/carrito";
	}

	// Ver el carrito
	@GetMapping("/carrito")
	public String verCarrito(HttpSession session, Model model) {
		if (!esCliente(session)) {
			return "redirect:/login";
		}
		List<LineaCarrito> lineas = new ArrayList<>();
		BigDecimal total = BigDecimal.ZERO;
		boolean hayEntradas = false;

		for (Map.Entry<Long, Integer> item : obtenerCarrito(session).entrySet()) {
			Producto p = productoRepository.findById(item.getKey()).orElse(null);
			if (p == null) {
				continue;
			}
			BigDecimal subtotal = p.getPrecio().multiply(BigDecimal.valueOf(item.getValue()));
			lineas.add(new LineaCarrito(p, item.getValue(), subtotal));
			total = total.add(subtotal);
			if ("entrada".equals(p.getTipo())) {
				hayEntradas = true;
			}
		}

		model.addAttribute("lineas", lineas);
		model.addAttribute("total", total);
		model.addAttribute("hayEntradas", hayEntradas);
		model.addAttribute("hoy", LocalDate.now().toString());
		return "carrito";
	}

	// Quitar un producto del carrito
	@PostMapping("/carrito/quitar/{id}")
	public String quitar(@PathVariable("id") Long id, HttpSession session) {
		if (!esCliente(session)) {
			return "redirect:/login";
		}
		obtenerCarrito(session).remove(id);
		return "redirect:/carrito";
	}

	// Finalizar la compra (formulario transaccional)
	@PostMapping("/carrito/comprar")
	public String comprar(@RequestParam(value = "fechaVisita", required = false) String fechaVisita,
			HttpServletRequest request, HttpSession session, RedirectAttributes ra) {

		if (!esCliente(session)) {
			return "redirect:/login";
		}
		Map<Long, Integer> carrito = obtenerCarrito(session);
		if (carrito.isEmpty()) {
			ra.addFlashAttribute("error", "Tu carrito está vacío.");
			return "redirect:/carrito";
		}

		// ¿Hay entradas en el carrito? Entonces hace falta la fecha de visita
		boolean hayEntradas = false;
		for (Long idProducto : carrito.keySet()) {
			Producto p = productoRepository.findById(idProducto).orElse(null);
			if (p != null && "entrada".equals(p.getTipo())) {
				hayEntradas = true;
			}
		}

		LocalDate fecha = null;
		if (hayEntradas) {
			if (fechaVisita == null || fechaVisita.isBlank()) {
				ra.addFlashAttribute("error", "Elige la fecha de visita para tus entradas.");
				return "redirect:/carrito";
			}
			try {
				fecha = LocalDate.parse(fechaVisita);
			} catch (Exception e) {
				ra.addFlashAttribute("error", "La fecha de visita no es válida.");
				return "redirect:/carrito";
			}
			if (fecha.isBefore(LocalDate.now())) {
				ra.addFlashAttribute("error", "La fecha de visita no puede ser anterior a hoy.");
				return "redirect:/carrito";
			}
		}

		Long idUsuario = (Long) session.getAttribute("idUsuario");
		try {
			Compra compra = compraService.comprar(idUsuario, carrito, fecha);
			// Cada compra deja un registro en la bitácora del administrador
			bitacoraService.registrar("Compra realizada #" + compra.getIdCompra(), request, idUsuario);
			carrito.clear();
			ra.addFlashAttribute("exito", "Compra registrada. Queda pendiente de aprobación del administrador.");
			return "redirect:/cliente";
		} catch (IllegalArgumentException e) {
			ra.addFlashAttribute("error", e.getMessage());
			return "redirect:/carrito";
		}
	}

}
