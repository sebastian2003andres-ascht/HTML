package com.nationalgallery.nationalgallery.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.nationalgallery.nationalgallery.model.Obra;
import com.nationalgallery.nationalgallery.model.Producto;
import com.nationalgallery.nationalgallery.repository.HistoriaRepository;
import com.nationalgallery.nationalgallery.repository.ObraRepository;
import com.nationalgallery.nationalgallery.repository.ProductoRepository;

// Páginas que puede ver cualquier visitante (sin iniciar sesión)
@Controller
public class PublicoController {

	private final ObraRepository obraRepository;
	private final HistoriaRepository historiaRepository;
	private final ProductoRepository productoRepository;

	public PublicoController(ObraRepository obraRepository, HistoriaRepository historiaRepository,
			ProductoRepository productoRepository) {
		this.obraRepository = obraRepository;
		this.historiaRepository = historiaRepository;
		this.productoRepository = productoRepository;
	}

	// ---------- HISTORIA ----------
	@GetMapping("/historia")
	public String historia(Model model) {
		model.addAttribute("historias", historiaRepository.findAllByOrderByAnioAsc());
		return "historia";
	}

	// ---------- OBRAS ----------
	@GetMapping("/obras")
	public String obras(@RequestParam(value = "q", required = false) String q, Model model) {
		List<Obra> lista;
		if (q == null || q.isBlank()) {
			lista = obraRepository.findAllByOrderByIdObraAsc();
		} else {
			lista = obraRepository.findByTituloContainingIgnoreCaseOrArtistaContainingIgnoreCase(q, q);
		}
		model.addAttribute("obras", lista);
		model.addAttribute("q", q);
		return "obras";
	}

	@GetMapping("/obras/{id}")
	public String obraDetalle(@PathVariable("id") Long id, Model model) {
		Obra obra = obraRepository.findById(id).orElse(null);
		if (obra == null) {
			return "redirect:/obras";
		}
		model.addAttribute("obra", obra);
		return "obra-detalle";
	}

	// ---------- TIENDA ----------
	@GetMapping("/tienda")
	public String tienda(@RequestParam(value = "tipo", required = false) String tipo, Model model) {
		List<Producto> lista;
		if (tipo == null || tipo.isBlank()) {
			lista = productoRepository.findAllByOrderByIdProductoAsc();
		} else {
			lista = productoRepository.findByTipoOrderByIdProductoAsc(tipo);
		}
		model.addAttribute("productos", lista);
		model.addAttribute("tipo", tipo);
		return "tienda";
	}

	@GetMapping("/tienda/{id}")
	public String productoDetalle(@PathVariable("id") Long id, Model model) {
		Producto producto = productoRepository.findById(id).orElse(null);
		if (producto == null) {
			return "redirect:/tienda";
		}
		model.addAttribute("producto", producto);
		return "producto-detalle";
	}

}
