package com.nationalgallery.nationalgallery.controller;

import java.time.LocalDateTime;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nationalgallery.nationalgallery.model.Usuario;
import com.nationalgallery.nationalgallery.repository.BitacoraRepository;
import com.nationalgallery.nationalgallery.repository.UsuarioRepository;
import com.nationalgallery.nationalgallery.service.BitacoraService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

// Todas las direcciones de este controlador empiezan con /admin
@Controller
@RequestMapping("/admin")
public class AdminController {

	private final UsuarioRepository usuarioRepository;
	private final BitacoraRepository bitacoraRepository;
	private final BitacoraService bitacoraService;
	private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	public AdminController(UsuarioRepository usuarioRepository, BitacoraRepository bitacoraRepository,
			BitacoraService bitacoraService) {
		this.usuarioRepository = usuarioRepository;
		this.bitacoraRepository = bitacoraRepository;
		this.bitacoraService = bitacoraService;
	}

	// Devuelve true si NO hay un administrador con sesión iniciada
	private boolean noEsAdmin(HttpSession session) {
		return !"administrador".equals(session.getAttribute("rol"));
	}

	// /admin lleva directo a la lista de usuarios
	@GetMapping
	public String inicio(HttpSession session) {
		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		return "redirect:/admin/usuarios";
	}

	// ---------- USUARIOS ----------

	// Lista de usuarios
	@GetMapping("/usuarios")
	public String usuarios(HttpSession session, Model model) {
		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		model.addAttribute("usuarios", usuarioRepository.findAllByOrderByIdUsuarioAsc());
		model.addAttribute("nombreAdmin", session.getAttribute("nombre"));
		return "admin-usuarios";
	}

	// Formulario para crear un usuario
	@GetMapping("/usuarios/nuevo")
	public String nuevo(HttpSession session, Model model) {
		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		model.addAttribute("usuario", new Usuario());
		return "admin-usuario-form";
	}

	// Formulario para editar un usuario
	@GetMapping("/usuarios/editar/{id}")
	public String editar(@PathVariable("id") Long id, HttpSession session, Model model) {
		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		Usuario u = usuarioRepository.findById(id).orElse(null);
		if (u == null) {
			return "redirect:/admin/usuarios";
		}
		model.addAttribute("usuario", u);
		return "admin-usuario-form";
	}

	// Guarda un usuario nuevo o los cambios de uno existente
	@PostMapping("/usuarios/guardar")
	public String guardar(@RequestParam(value = "idUsuario", required = false) Long idUsuario,
			@RequestParam("nombre") String nombre,
			@RequestParam("correo") String correo,
			@RequestParam("contrasena") String contrasena,
			@RequestParam("rol") String rol,
			HttpServletRequest request, HttpSession session, Model model) {

		if (noEsAdmin(session)) {
			return "redirect:/login";
		}

		boolean esNuevo = (idUsuario == null);

		// Guardamos lo escrito para volver a mostrarlo si hay un error
		Usuario form = new Usuario();
		form.setIdUsuario(idUsuario);
		form.setNombre(nombre);
		form.setCorreo(correo);
		form.setRol(rol);
		model.addAttribute("usuario", form);

		// Validaciones
		if (nombre.isBlank()) {
			model.addAttribute("error", "El nombre es obligatorio.");
			return "admin-usuario-form";
		}
		if (!correo.matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")) {
			model.addAttribute("error", "El correo no tiene un formato válido.");
			return "admin-usuario-form";
		}
		Usuario otro = usuarioRepository.findByCorreo(correo);
		if (otro != null && !otro.getIdUsuario().equals(idUsuario)) {
			model.addAttribute("error", "Ese correo ya está registrado.");
			return "admin-usuario-form";
		}
		if (!rol.equals("cliente") && !rol.equals("empleado") && !rol.equals("administrador")) {
			model.addAttribute("error", "El rol no es válido.");
			return "admin-usuario-form";
		}
		if (esNuevo && !contrasena.matches("^.{8,}$")) {
			model.addAttribute("error", "La contraseña debe tener mínimo 8 caracteres.");
			return "admin-usuario-form";
		}
		if (!esNuevo && !contrasena.isBlank() && !contrasena.matches("^.{8,}$")) {
			model.addAttribute("error", "La contraseña nueva debe tener mínimo 8 caracteres.");
			return "admin-usuario-form";
		}
		if (!esNuevo && idUsuario.equals(session.getAttribute("idUsuario")) && !rol.equals("administrador")) {
			model.addAttribute("error", "No puedes quitarte a ti mismo el rol de administrador.");
			return "admin-usuario-form";
		}

		// Todo está bien: creamos o actualizamos
		Usuario u;
		if (esNuevo) {
			u = new Usuario();
			u.setBloqueado(false);
			u.setFechaRegistro(LocalDateTime.now());
			u.setContrasena(encoder.encode(contrasena));
		} else {
			u = usuarioRepository.findById(idUsuario).orElse(null);
			if (u == null) {
				return "redirect:/admin/usuarios";
			}
			// Si dejó la contraseña vacía, se queda la que ya tenía
			if (!contrasena.isBlank()) {
				u.setContrasena(encoder.encode(contrasena));
			}
		}
		u.setNombre(nombre);
		u.setCorreo(correo);
		u.setRol(rol);
		usuarioRepository.save(u);

		String accion = esNuevo ? "Administrador creó el usuario: " : "Administrador actualizó el usuario: ";
		bitacoraService.registrar(accion + correo, request, (Long) session.getAttribute("idUsuario"));

		return "redirect:/admin/usuarios";
	}

	// Bloquear o desbloquear (bloqueo lógico: no se borra el usuario)
	@PostMapping("/usuarios/bloquear/{id}")
	public String bloquear(@PathVariable("id") Long id, HttpServletRequest request, HttpSession session) {
		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		Usuario u = usuarioRepository.findById(id).orElse(null);
		// El administrador no puede bloquearse a sí mismo
		if (u != null && !u.getIdUsuario().equals(session.getAttribute("idUsuario"))) {
			boolean ahoraBloqueado = !Boolean.TRUE.equals(u.getBloqueado()); // invierte el valor
			u.setBloqueado(ahoraBloqueado);
			usuarioRepository.save(u);

			String accion = ahoraBloqueado ? "Administrador bloqueó al usuario: " : "Administrador desbloqueó al usuario: ";
			bitacoraService.registrar(accion + u.getCorreo(), request, (Long) session.getAttribute("idUsuario"));
		}
		return "redirect:/admin/usuarios";
	}

	// ---------- BITÁCORA ----------

	@GetMapping("/bitacora")
	public String bitacora(HttpSession session, Model model) {
		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		model.addAttribute("registros", bitacoraRepository.findAllByOrderByFechaHoraDesc());
		model.addAttribute("nombreAdmin", session.getAttribute("nombre"));
		return "admin-bitacora";
	}

}
