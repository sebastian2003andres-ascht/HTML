package com.nationalgallery.nationalgallery.controller;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nationalgallery.nationalgallery.model.Compra;
import com.nationalgallery.nationalgallery.model.CompraVista;
import com.nationalgallery.nationalgallery.model.DetalleCompra;
import com.nationalgallery.nationalgallery.model.Producto;
import com.nationalgallery.nationalgallery.model.Usuario;
import com.nationalgallery.nationalgallery.repository.CompraRepository;
import com.nationalgallery.nationalgallery.repository.DetalleCompraRepository;
import com.nationalgallery.nationalgallery.repository.ProductoRepository;
import com.nationalgallery.nationalgallery.repository.UsuarioRepository;
import com.nationalgallery.nationalgallery.service.BitacoraService;
import com.nationalgallery.nationalgallery.service.CompraService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

// El administrador revisa y aprueba (o rechaza) las compras de los clientes
@Controller
@RequestMapping("/admin/aprobaciones")
public class AprobacionController {

	private final CompraRepository compraRepository;
	private final DetalleCompraRepository detalleCompraRepository;
	private final ProductoRepository productoRepository;
	private final UsuarioRepository usuarioRepository;
	private final CompraService compraService;
	private final BitacoraService bitacoraService;

	public AprobacionController(CompraRepository compraRepository, DetalleCompraRepository detalleCompraRepository,
			ProductoRepository productoRepository, UsuarioRepository usuarioRepository,
			CompraService compraService, BitacoraService bitacoraService) {
		this.compraRepository = compraRepository;
		this.detalleCompraRepository = detalleCompraRepository;
		this.productoRepository = productoRepository;
		this.usuarioRepository = usuarioRepository;
		this.compraService = compraService;
		this.bitacoraService = bitacoraService;
	}

	// Devuelve true si NO hay un administrador con sesión iniciada
	private boolean noEsAdmin(HttpSession session) {
		return !"administrador".equals(session.getAttribute("rol"));
	}

	// Lista de compras. Por defecto muestra las pendientes.
	// /admin/aprobaciones?estado=aprobada | rechazada | todas
	@GetMapping
	public String lista(@RequestParam(value = "estado", required = false) String estado,
			HttpSession session, Model model) {

		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		if (estado == null || estado.isBlank()) {
			estado = "pendiente";
		}
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

		List<CompraVista> lista = new ArrayList<>();
		for (Compra c : compraRepository.findAllByOrderByFechaDesc()) {
			if (!estado.equals("todas") && !estado.equals(c.getEstado())) {
				continue;
			}
			Usuario cliente = usuarioRepository.findById(c.getIdUsuario()).orElse(null);

			CompraVista v = new CompraVista();
			v.setIdCompra(c.getIdCompra());
			v.setFecha(c.getFecha().format(formato));
			v.setFechaVisita(c.getFechaVisita() == null ? "-" : c.getFechaVisita().toString());
			v.setCliente(cliente == null ? "(usuario eliminado)" : cliente.getNombre());
			v.setTotal(c.getTotal());
			v.setEstado(c.getEstado());

			for (DetalleCompra d : detalleCompraRepository.findByIdCompra(c.getIdCompra())) {
				Producto p = productoRepository.findById(d.getIdProducto()).orElse(null);
				String nombreProducto = (p == null) ? "Producto" : p.getNombre();
				v.getLineas().add(d.getCantidad() + " x " + nombreProducto);
			}
			lista.add(v);
		}

		model.addAttribute("compras", lista);
		model.addAttribute("estado", estado);
		return "admin-aprobaciones";
	}

	// Aprobar
	@PostMapping("/aprobar/{id}")
	public String aprobar(@PathVariable("id") Long id, HttpServletRequest request, HttpSession session,
			RedirectAttributes ra) {
		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		try {
			compraService.aprobar(id);
			bitacoraService.registrar("Administrador aprobó la compra #" + id, request,
					(Long) session.getAttribute("idUsuario"));
			ra.addFlashAttribute("exito", "Compra #" + id + " aprobada.");
		} catch (IllegalArgumentException e) {
			ra.addFlashAttribute("error", e.getMessage());
		}
		return "redirect:/admin/aprobaciones";
	}

	// Rechazar (el stock vuelve a la tienda)
	@PostMapping("/rechazar/{id}")
	public String rechazar(@PathVariable("id") Long id, HttpServletRequest request, HttpSession session,
			RedirectAttributes ra) {
		if (noEsAdmin(session)) {
			return "redirect:/login";
		}
		try {
			compraService.rechazar(id);
			bitacoraService.registrar("Administrador rechazó la compra #" + id, request,
					(Long) session.getAttribute("idUsuario"));
			ra.addFlashAttribute("exito", "Compra #" + id + " rechazada. El stock volvió a la tienda.");
		} catch (IllegalArgumentException e) {
			ra.addFlashAttribute("error", e.getMessage());
		}
		return "redirect:/admin/aprobaciones";
	}

}
