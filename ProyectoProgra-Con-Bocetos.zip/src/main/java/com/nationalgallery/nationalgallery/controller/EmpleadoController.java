package com.nationalgallery.nationalgallery.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nationalgallery.nationalgallery.model.Compra;
import com.nationalgallery.nationalgallery.model.CompraVista;
import com.nationalgallery.nationalgallery.model.DetalleCompra;
import com.nationalgallery.nationalgallery.model.Historia;
import com.nationalgallery.nationalgallery.model.Obra;
import com.nationalgallery.nationalgallery.model.Producto;
import com.nationalgallery.nationalgallery.model.Usuario;
import com.nationalgallery.nationalgallery.repository.CompraRepository;
import com.nationalgallery.nationalgallery.repository.DetalleCompraRepository;
import com.nationalgallery.nationalgallery.repository.HistoriaRepository;
import com.nationalgallery.nationalgallery.repository.ObraRepository;
import com.nationalgallery.nationalgallery.repository.ProductoRepository;
import com.nationalgallery.nationalgallery.repository.UsuarioRepository;
import com.nationalgallery.nationalgallery.service.BitacoraService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

// Perfil Empleado: administra obras, historia y productos, y ve las compras de todos los clientes.
// Todas las direcciones empiezan con /empleado
@Controller
@RequestMapping("/empleado")
public class EmpleadoController {

	private final ObraRepository obraRepository;
	private final HistoriaRepository historiaRepository;
	private final ProductoRepository productoRepository;
	private final CompraRepository compraRepository;
	private final DetalleCompraRepository detalleCompraRepository;
	private final UsuarioRepository usuarioRepository;
	private final BitacoraService bitacoraService;

	public EmpleadoController(ObraRepository obraRepository, HistoriaRepository historiaRepository,
			ProductoRepository productoRepository, CompraRepository compraRepository,
			DetalleCompraRepository detalleCompraRepository, UsuarioRepository usuarioRepository,
			BitacoraService bitacoraService) {
		this.obraRepository = obraRepository;
		this.historiaRepository = historiaRepository;
		this.productoRepository = productoRepository;
		this.compraRepository = compraRepository;
		this.detalleCompraRepository = detalleCompraRepository;
		this.usuarioRepository = usuarioRepository;
		this.bitacoraService = bitacoraService;
	}

	// ---------- Ayudas ----------

	// Devuelve true si NO hay un empleado con sesión iniciada
	private boolean noEsEmpleado(HttpSession session) {
		return !"empleado".equals(session.getAttribute("rol"));
	}

	// Anota en la bitácora lo que hizo el empleado
	private void anotar(String accion, HttpServletRequest request, HttpSession session) {
		bitacoraService.registrar(accion, request, (Long) session.getAttribute("idUsuario"));
	}

	// Un texto vacío se guarda como null
	private String vacioANulo(String texto) {
		if (texto == null || texto.isBlank()) {
			return null;
		}
		return texto.trim();
	}

	// Convierte "2026-11-20" en fecha; si está vacío o mal escrito devuelve null
	private LocalDate leerFecha(String texto) {
		try {
			return LocalDate.parse(texto);
		} catch (Exception e) {
			return null;
		}
	}

	// /empleado lleva directo a las obras
	@GetMapping
	public String inicio(HttpSession session) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		return "redirect:/empleado/obras";
	}

	// =====================================================
	// OBRAS
	// =====================================================

	@GetMapping("/obras")
	public String obras(HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		model.addAttribute("obras", obraRepository.findAllByOrderByIdObraAsc());
		return "empleado-obras";
	}

	@GetMapping("/obras/nueva")
	public String nuevaObra(HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		model.addAttribute("obra", new Obra());
		return "empleado-obra-form";
	}

	@GetMapping("/obras/editar/{id}")
	public String editarObra(@PathVariable("id") Long id, HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		Obra o = obraRepository.findById(id).orElse(null);
		if (o == null) {
			return "redirect:/empleado/obras";
		}
		model.addAttribute("obra", o);
		return "empleado-obra-form";
	}

	@PostMapping("/obras/guardar")
	public String guardarObra(@RequestParam(value = "idObra", required = false) Long idObra,
			@RequestParam("titulo") String titulo,
			@RequestParam("artista") String artista,
			@RequestParam(value = "anio", required = false) Integer anio,
			@RequestParam("sala") String sala,
			@RequestParam("descripcion") String descripcion,
			@RequestParam("imagen") String imagen,
			HttpServletRequest request, HttpSession session, Model model) {

		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}

		// Guardamos lo escrito para volver a mostrarlo si hay un error
		Obra form = new Obra();
		form.setIdObra(idObra);
		form.setTitulo(titulo);
		form.setArtista(artista);
		form.setAnio(anio);
		form.setSala(sala);
		form.setDescripcion(descripcion);
		form.setImagen(imagen);
		model.addAttribute("obra", form);

		if (titulo.isBlank()) {
			model.addAttribute("error", "El título es obligatorio.");
			return "empleado-obra-form";
		}
		if (artista.isBlank()) {
			model.addAttribute("error", "El artista es obligatorio.");
			return "empleado-obra-form";
		}

		boolean esNueva = (idObra == null);
		Obra o = esNueva ? new Obra() : obraRepository.findById(idObra).orElse(null);
		if (o == null) {
			return "redirect:/empleado/obras";
		}
		o.setTitulo(titulo.trim());
		o.setArtista(artista.trim());
		o.setAnio(anio);
		o.setSala(vacioANulo(sala));
		o.setDescripcion(vacioANulo(descripcion));
		o.setImagen(vacioANulo(imagen));
		obraRepository.save(o);

		anotar((esNueva ? "Empleado creó la obra: " : "Empleado actualizó la obra: ") + titulo, request, session);
		return "redirect:/empleado/obras";
	}

	@PostMapping("/obras/eliminar/{id}")
	public String eliminarObra(@PathVariable("id") Long id, HttpServletRequest request, HttpSession session) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		Obra o = obraRepository.findById(id).orElse(null);
		if (o != null) {
			obraRepository.delete(o);
			anotar("Empleado eliminó la obra: " + o.getTitulo(), request, session);
		}
		return "redirect:/empleado/obras";
	}

	// =====================================================
	// HISTORIA
	// =====================================================

	@GetMapping("/historia")
	public String historia(HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		model.addAttribute("historias", historiaRepository.findAllByOrderByAnioAsc());
		return "empleado-historia";
	}

	@GetMapping("/historia/nueva")
	public String nuevaHistoria(HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		model.addAttribute("historia", new Historia());
		return "empleado-historia-form";
	}

	@GetMapping("/historia/editar/{id}")
	public String editarHistoria(@PathVariable("id") Long id, HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		Historia h = historiaRepository.findById(id).orElse(null);
		if (h == null) {
			return "redirect:/empleado/historia";
		}
		model.addAttribute("historia", h);
		return "empleado-historia-form";
	}

	@PostMapping("/historia/guardar")
	public String guardarHistoria(@RequestParam(value = "idHistoria", required = false) Long idHistoria,
			@RequestParam(value = "anio", required = false) Integer anio,
			@RequestParam("titulo") String titulo,
			@RequestParam("contenido") String contenido,
			@RequestParam("imagen") String imagen,
			HttpServletRequest request, HttpSession session, Model model) {

		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}

		Historia form = new Historia();
		form.setIdHistoria(idHistoria);
		form.setAnio(anio);
		form.setTitulo(titulo);
		form.setContenido(contenido);
		form.setImagen(imagen);
		model.addAttribute("historia", form);

		if (titulo.isBlank()) {
			model.addAttribute("error", "El título es obligatorio.");
			return "empleado-historia-form";
		}
		if (contenido.isBlank()) {
			model.addAttribute("error", "El contenido es obligatorio.");
			return "empleado-historia-form";
		}

		boolean esNueva = (idHistoria == null);
		Historia h = esNueva ? new Historia() : historiaRepository.findById(idHistoria).orElse(null);
		if (h == null) {
			return "redirect:/empleado/historia";
		}
		h.setAnio(anio);
		h.setTitulo(titulo.trim());
		h.setContenido(contenido.trim());
		h.setImagen(vacioANulo(imagen));
		historiaRepository.save(h);

		anotar((esNueva ? "Empleado creó un registro de historia: " : "Empleado actualizó un registro de historia: ") + titulo, request, session);
		return "redirect:/empleado/historia";
	}

	@PostMapping("/historia/eliminar/{id}")
	public String eliminarHistoria(@PathVariable("id") Long id, HttpServletRequest request, HttpSession session) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		Historia h = historiaRepository.findById(id).orElse(null);
		if (h != null) {
			historiaRepository.delete(h);
			anotar("Empleado eliminó un registro de historia: " + h.getTitulo(), request, session);
		}
		return "redirect:/empleado/historia";
	}

	// =====================================================
	// PRODUCTOS
	// =====================================================

	@GetMapping("/productos")
	public String productos(HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		model.addAttribute("productos", productoRepository.findAllByOrderByIdProductoAsc());
		return "empleado-productos";
	}

	@GetMapping("/productos/nuevo")
	public String nuevoProducto(HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		model.addAttribute("producto", new Producto());
		return "empleado-producto-form";
	}

	@GetMapping("/productos/editar/{id}")
	public String editarProducto(@PathVariable("id") Long id, HttpSession session, Model model) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		Producto p = productoRepository.findById(id).orElse(null);
		if (p == null) {
			return "redirect:/empleado/productos";
		}
		model.addAttribute("producto", p);
		return "empleado-producto-form";
	}

	@PostMapping("/productos/guardar")
	public String guardarProducto(@RequestParam(value = "idProducto", required = false) Long idProducto,
			@RequestParam("nombre") String nombre,
			@RequestParam("tipo") String tipo,
			@RequestParam("descripcion") String descripcion,
			@RequestParam(value = "precio", required = false) BigDecimal precio,
			@RequestParam(value = "stock", required = false) Integer stock,
			@RequestParam("imagen") String imagen,
			HttpServletRequest request, HttpSession session, Model model) {

		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}

		Producto form = new Producto();
		form.setIdProducto(idProducto);
		form.setNombre(nombre);
		form.setTipo(tipo);
		form.setDescripcion(descripcion);
		form.setPrecio(precio);
		form.setStock(stock);
		form.setImagen(imagen);
		model.addAttribute("producto", form);

		if (nombre.isBlank()) {
			model.addAttribute("error", "El nombre es obligatorio.");
			return "empleado-producto-form";
		}
		if (!tipo.equals("entrada") && !tipo.equals("libro") && !tipo.equals("postal") && !tipo.equals("recuerdo")) {
			model.addAttribute("error", "El tipo no es válido.");
			return "empleado-producto-form";
		}
		if (precio == null || precio.compareTo(BigDecimal.ZERO) < 0) {
			model.addAttribute("error", "El precio debe ser un número mayor o igual a 0.");
			return "empleado-producto-form";
		}
		if (stock == null || stock < 0) {
			model.addAttribute("error", "El stock debe ser un número mayor o igual a 0.");
			return "empleado-producto-form";
		}

		boolean esNuevo = (idProducto == null);
		Producto p = esNuevo ? new Producto() : productoRepository.findById(idProducto).orElse(null);
		if (p == null) {
			return "redirect:/empleado/productos";
		}
		p.setNombre(nombre.trim());
		p.setTipo(tipo);
		p.setDescripcion(vacioANulo(descripcion));
		p.setPrecio(precio);
		p.setStock(stock);
		p.setImagen(vacioANulo(imagen));
		productoRepository.save(p);

		anotar((esNuevo ? "Empleado creó el producto: " : "Empleado actualizó el producto: ") + nombre, request, session);
		return "redirect:/empleado/productos";
	}

	@PostMapping("/productos/eliminar/{id}")
	public String eliminarProducto(@PathVariable("id") Long id, HttpServletRequest request, HttpSession session,
			RedirectAttributes ra) {
		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}
		Producto p = productoRepository.findById(id).orElse(null);
		if (p != null) {
			try {
				productoRepository.delete(p);
				anotar("Empleado eliminó el producto: " + p.getNombre(), request, session);
			} catch (DataIntegrityViolationException e) {
				// Un producto que ya se compró no se puede borrar (rompería el histórico)
				ra.addFlashAttribute("error", "No se puede eliminar \"" + p.getNombre()
						+ "\" porque ya tiene compras. Puedes poner su stock en 0.");
			}
		}
		return "redirect:/empleado/productos";
	}

	// =====================================================
	// HISTÓRICO DE COMPRAS DE TODOS LOS CLIENTES
	// =====================================================

	@GetMapping("/compras")
	public String compras(@RequestParam(value = "desde", required = false) String desde,
			@RequestParam(value = "hasta", required = false) String hasta,
			HttpSession session, Model model) {

		if (noEsEmpleado(session)) {
			return "redirect:/login";
		}

		LocalDate fechaDesde = leerFecha(desde);
		LocalDate fechaHasta = leerFecha(hasta);
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

		List<CompraVista> lista = new ArrayList<>();
		for (Compra c : compraRepository.findAllByOrderByFechaDesc()) {

			// Filtro por fechas (si el empleado puso alguna)
			LocalDate dia = c.getFecha().toLocalDate();
			if (fechaDesde != null && dia.isBefore(fechaDesde)) {
				continue;
			}
			if (fechaHasta != null && dia.isAfter(fechaHasta)) {
				continue;
			}

			Usuario cliente = usuarioRepository.findById(c.getIdUsuario()).orElse(null);

			CompraVista v = new CompraVista();
			v.setIdCompra(c.getIdCompra());
			v.setFecha(c.getFecha().format(formato));
			v.setFechaVisita(c.getFechaVisita() == null ? "-" : c.getFechaVisita().toString());
			v.setCliente(cliente == null ? "(usuario eliminado)" : cliente.getNombre());
			v.setTotal(c.getTotal());
			v.setEstado(c.getEstado());

			for (DetalleCompra d : detalleCompraRepository.findByIdCompra(c.getIdCompra())) {
				Producto p = productoRepository.findById(d.getIdProducto()).orElse(null);
				String nombreProducto = (p == null) ? "Producto" : p.getNombre();
				v.getLineas().add(d.getCantidad() + " x " + nombreProducto);
			}
			lista.add(v);
		}

		model.addAttribute("compras", lista);
		model.addAttribute("desde", desde);
		model.addAttribute("hasta", hasta);
		return "empleado-compras";
	}

}
